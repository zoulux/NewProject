package com.ehsy.lua.commoditylist.presenter;

/**
 * Created by Lua on 2015/12/24 15:53.
 */
public interface ILoginPresenter {
    void login(String phone,String pwd);
}
