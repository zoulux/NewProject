package com.ehsy.lua.commoditylist.presenter.impl;

import android.text.TextUtils;
import android.util.Log;

import com.ehsy.lua.commoditylist.common.HttpListener;
import com.ehsy.lua.commoditylist.common.HttpParameters;
import com.ehsy.lua.commoditylist.presenter.ILoginPresenter;
import com.ehsy.lua.commoditylist.utils.CommonUtils;
import com.ehsy.lua.commoditylist.utils.VolleyUtils;
import com.ehsy.lua.commoditylist.view.ILoginView;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Lua on 2015/12/24 15:54.
 */
public class LoginPresenter implements ILoginPresenter, HttpListener {
    private static final String TAG = "LoginPresenter";
    private ILoginView loginView;

    public  LoginPresenter(ILoginView loginView){
        this.loginView=loginView;
    }

    @Override
    public void login(String phone, String pwd) {

        Map<String, String> map = new HashMap<>();
        map.put("module", "user/login");
        map.put("mobile", phone);
        map.put("password", pwd);

        HttpParameters parameters = new HttpParameters(map);
        VolleyUtils.request(parameters, this);

    }

    @Override
    public void success(HttpParameters parameters) {

        Log.d(TAG, "success :" + parameters.result);

        if (! TextUtils.isEmpty(CommonUtils.parameterGetResult(parameters, "info"))){
            loginView.onFaild(CommonUtils.parameterGetResult(parameters, "info"));
        }else{
            loginView.onSuccess("用户名："+CommonUtils.parameterGetResult(parameters, "username"));
        }


    }

    @Override
    public void faild(HttpParameters parameters) {
        loginView.onFaild(parameters.result);
    }
}
