package com.ehsy.lua.commoditylist.presenter;

import com.ehsy.lua.commoditylist.model.ProductModel;

import java.util.List;

/**
 * Created by Lua on 2015/12/25 14:40.
 */
public interface IShopCarPresenter {
    void selectAll(List<ProductModel> products);
    void cleanAll(List<ProductModel> products);

    void loadData();

    void reduce(ProductModel product);

    void add(ProductModel product);

    void checkBoxOnChanged(ProductModel product, boolean isChecked);


    void selectAllChanged(boolean isChecked);

    void delete(ProductModel product);

    void gotoPay();
}
