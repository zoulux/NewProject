package com.ehsy.lua.commoditylist.view;

import com.ehsy.lua.commoditylist.model.ProductModel;

import java.util.List;

/**
 * Created by Lua on 2015/12/24 15:04.
 */
public interface IFindView {
    void onSuccess(List<ProductModel> models);
    void onFaild(String  faild);
}
