package com.ehsy.lua.commoditylist.biz;

import com.ehsy.lua.commoditylist.application.App;
import com.ehsy.lua.commoditylist.common.HttpListener;
import com.ehsy.lua.commoditylist.common.HttpParameters;
import com.ehsy.lua.commoditylist.model.Product;
import com.ehsy.lua.commoditylist.utils.VolleyUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Lua on 2015/12/30 9:20.
 */
public class ProductBiz {

    public void loadData(String keyWord,HttpListener listener) {
        Map<String, String> map = new HashMap<>();
        map.put("module", "search/result");
        map.put("keywords", keyWord);
        map.put("page", "10");
        map.put("sort", "price");
        map.put("order", "asc");
        HttpParameters parameters = new HttpParameters(map);
        VolleyUtils.request(parameters, listener);
    }
    public void reduce(Product product) {
        Map<Product, Integer> buyCar = App.getBuyCar();
        Integer newCount = buyCar.get(product) - 1;
        if (newCount <= 0) {
            newCount = 0;
        }
        buyCar.put(product, newCount);

    }

    public void add(Product product) {
        Map<Product, Integer> shopCar = App.getBuyCar();
        Integer newCount = shopCar.get(product) + 1;
        shopCar.put(product, newCount);
    }

    public void delete(Product product) {
        Map<Product, Integer> shopCar = App.getBuyCar();
        shopCar.remove(product);

    }
}
