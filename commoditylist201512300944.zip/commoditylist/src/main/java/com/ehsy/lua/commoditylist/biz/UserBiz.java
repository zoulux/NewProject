package com.ehsy.lua.commoditylist.biz;

import com.ehsy.lua.commoditylist.common.HttpListener;
import com.ehsy.lua.commoditylist.common.HttpParameters;
import com.ehsy.lua.commoditylist.model.User;
import com.ehsy.lua.commoditylist.utils.VolleyUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Lua on 2015/12/30 9:05.
 */
public class UserBiz {

    public void register(User user, String authCode,HttpListener listener) {
        Map<String, String> params = new HashMap<>();
        params.put("mobile", user.getPhone());
        params.put("password", user.getPwd());
        params.put("auth_code", authCode);
        params.put("ref_uid", "1111");
        params.put("module", "user/registerphone");

        HttpParameters parameters = new HttpParameters();
        parameters.params = params;
        VolleyUtils.request(parameters, listener);
    }

    public  void sendAuthCode(String phone,HttpListener listener){

        Map<String, String> params = new HashMap<>();
        params.put("mobile", phone);
        params.put("channel", "1");
        params.put("module", "user/sendsms");
        HttpParameters parameters = new HttpParameters(params);
        VolleyUtils.request(parameters, listener);
    }

    public void forgot(User user, String authCode,HttpListener listener) {
        Map<String, String> map = new HashMap<>();
        map.put("mobile", user.getPhone());
        map.put("password", user.getPwd());
        map.put("auth_code", authCode);
        map.put("module", "user/forgotpwd");

        HttpParameters parameters = new HttpParameters(map);
        VolleyUtils.request(parameters, listener);
    }

    public void login(User user,HttpListener listener) {

        Map<String, String> map = new HashMap<>();
        map.put("module", "user/login");
        map.put("mobile", user.getPhone());
        map.put("password", user.getPwd());

        HttpParameters parameters = new HttpParameters(map);
        VolleyUtils.request(parameters, listener);

    }


}
