package com.ehsy.lua.commoditylist.presenter.impl;

import com.ehsy.lua.commoditylist.common.HttpListener;
import com.ehsy.lua.commoditylist.common.HttpParameters;
import com.ehsy.lua.commoditylist.presenter.IRegisterPresenter;
import com.ehsy.lua.commoditylist.utils.CommonUtils;
import com.ehsy.lua.commoditylist.utils.VolleyUtils;
import com.ehsy.lua.commoditylist.view.IRegisterView;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Lua on 2015/12/24 16:27.
 */
public class RegisterPresenter implements IRegisterPresenter, HttpListener {
    private IRegisterView registerView;

    public  RegisterPresenter(IRegisterView registerView){
            this.registerView=registerView;
    }
    @Override
    public void register(String phone, String pwd, String authCode) {
        Map<String, String> params = new HashMap<>();
        params.put("mobile", phone);
        params.put("password", pwd);
        params.put("auth_code", authCode);
        params.put("ref_uid", "1111");
        params.put("module", "user/registerphone");

        HttpParameters parameters = new HttpParameters();
        parameters.params = params;
        VolleyUtils.request(parameters, this);
    }

    @Override
    public void sendAuthCode(String phone) {
        CommonUtils.sendAuthCode(phone,this);
    }

    @Override
    public void success(HttpParameters parameters) {
        registerView.onSuccess(CommonUtils.parameterGetResult(parameters,"info"));

    }

    @Override
    public void faild(HttpParameters parameters) {
        registerView.onFaild(CommonUtils.parameterGetResult(parameters,"info"));
    }
}
