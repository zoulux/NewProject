package com.ehsy.lua.commoditylist.bean;

/**
 * Created by Lua on 2015/12/24 11:14.
 */
public class Pages {
    String pages;
    String page;
    String prepage;
    String nextpage;
}
