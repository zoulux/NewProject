package com.ehsy.lua.commoditylist.common;

/**
 * Created by Lua on 2015/12/24 11:41.
 */
public interface HttpListener {
    public void success(HttpParameters parameters);
    public void faild(HttpParameters parameters);
}
