package com.ehsy.lua.commoditylist.presenter.impl;

import com.ehsy.lua.commoditylist.common.HttpListener;
import com.ehsy.lua.commoditylist.common.HttpParameters;
import com.ehsy.lua.commoditylist.presenter.IForgotPwdPresenter;
import com.ehsy.lua.commoditylist.utils.CommonUtils;
import com.ehsy.lua.commoditylist.utils.VolleyUtils;
import com.ehsy.lua.commoditylist.view.IForgotPwdView;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Lua on 2015/12/24 17:08.
 */
public class ForgotPwdPresenter implements IForgotPwdPresenter, HttpListener {
    private IForgotPwdView forgotPwdView;

    public ForgotPwdPresenter(IForgotPwdView forgotPwdView) {
        this.forgotPwdView = forgotPwdView;
    }

    @Override
    public void forgot(String phone, String pwd, String authCode) {
        Map<String, String> map = new HashMap<>();
        map.put("mobile", phone);
        map.put("password", pwd);
        map.put("auth_code", authCode);
        map.put("module", "user/forgotpwd");

        HttpParameters parameters = new HttpParameters(map);
        VolleyUtils.request(parameters, this);
    }

    @Override
    public void sendAuthCode(String phone) {

        CommonUtils.sendAuthCode(phone, this);
    }

    @Override
    public void success(HttpParameters parameters) {

        forgotPwdView.onSuccess(CommonUtils.parameterGetResult(parameters,"info"));

    }

    @Override
    public void faild(HttpParameters parameters) {

        forgotPwdView.onFaild(CommonUtils.parameterGetResult(parameters,"info"));
    }
}
